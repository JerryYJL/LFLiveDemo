//
//  PlayViewController.h
//  LFLiveDemo
//
//  Created by Apple on 16/9/1.
//  Copyright © 2016年 JunLiu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayViewController : UIViewController

@end
