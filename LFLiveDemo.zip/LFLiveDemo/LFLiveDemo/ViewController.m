//
//  ViewController.m
//  LFLiveDemo
//
//  Created by Apple on 16/9/1.
//  Copyright © 2016年 JunLiu. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "LFLiveKit.h"
#import "PlayViewController.h"

@interface ViewController ()<LFLiveSessionDelegate>
@property(nonatomic,strong)UIButton *liveButton;
@property(nonatomic,strong)UIButton *playButton;
@property(nonatomic,strong)UIButton *cameraButton;
@property(nonatomic,assign)BOOL flag;
@property(nonatomic,strong)LFLiveSession *session;
@property(nonatomic,strong)UILabel *stateLabel;
@end

@implementation ViewController

-(UIButton *)liveButton{
    if (!_liveButton) {
        _liveButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _liveButton.frame = CGRectMake(self.view.frame.size.width/2-self.view.frame.size.width/4, self.view.frame.size.height-84, self.view.frame.size.width/2, 44);
        [_liveButton setTitle:@"开始直播" forState:0];
        _liveButton.backgroundColor = [UIColor lightGrayColor];
        _liveButton.layer.cornerRadius = 4.0;
        _liveButton.layer.masksToBounds = YES;
        [_liveButton addTarget:self action:@selector(startAction:) forControlEvents:UIControlEventTouchUpInside];
        
    }
    return _liveButton;
}

-(UIButton *)playButton{
    if (!_playButton) {
        _playButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _playButton.frame = CGRectMake(0, 64, 44, 44);
        [_playButton setTitle:@"播放" forState:0];
        _playButton.backgroundColor = [UIColor clearColor];
        [_playButton setTitleColor:[UIColor blueColor] forState:0];
        [_playButton addTarget:self action:@selector(playAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _playButton;
}

-(UIButton *)cameraButton{
    if (!_cameraButton) {
        _cameraButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _cameraButton.frame = CGRectMake(self.view.frame.size.width/2-22, 64, 44, 44);
        [_cameraButton setImage:[UIImage imageNamed:@"camra_preview"] forState:0];
        _cameraButton.exclusiveTouch = YES;
        [_cameraButton addTarget:self action:@selector(cameraAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _cameraButton;
}

-(UILabel *)stateLabel{
    if (!_stateLabel) {
        _stateLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width-64, 64, 44, 44)];
        _stateLabel.text = @"未连接";
        _stateLabel.textColor = [UIColor blueColor];
        _stateLabel.font = [UIFont systemFontOfSize:14.0];
    }
    return _stateLabel;
}

-(LFLiveSession *)session{
    if (!_session) {
        _session = [[LFLiveSession alloc]initWithAudioConfiguration:[LFLiveAudioConfiguration defaultConfiguration] videoConfiguration:[LFLiveVideoConfiguration defaultConfiguration]];
        _session.running = YES;
        _session.preView = self.view;
        _session.delegate = self;
        _session.showDebugInfo = NO;
    }
    return _session;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _flag = YES;
    [self.view addSubview:self.liveButton];
    [self.view addSubview:self.playButton];
    [self.view addSubview:self.stateLabel];
    [self.view addSubview:self.cameraButton];
    [self Video];
    
}

-(void)startAction:(UIButton *)sender{
    if (_flag) {
        [sender setTitle:@"结束直播" forState:0];
        LFLiveStreamInfo *stream = [[LFLiveStreamInfo alloc]init];
        stream.url = @"rtmp://live.hkstv.hk.lxdns.com:1935/live/stream152";
        [self.session startLive:stream];
    }else{
        [sender setTitle:@"开始直播" forState:0];
        [self.session stopLive];
    }
    _flag = !_flag;
}

-(void)playAction:(UIButton *)sender{
    [self.session stopLive];
    [_liveButton setTitle:@"开始直播" forState:0];
    _flag = YES;
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    PlayViewController *playVC = [storyboard instantiateViewControllerWithIdentifier:@"PlayViewController"];
    [self.navigationController pushViewController:playVC animated:YES];
}

-(void)cameraAction:(UIButton *)sender{
    AVCaptureDevicePosition devicePosition = self.session.captureDevicePosition;
    self.session.captureDevicePosition = (devicePosition == AVCaptureDevicePositionBack) ? AVCaptureDevicePositionFront : AVCaptureDevicePositionBack;
}

-(void)Video{
    __weak typeof (self) _self = self;
    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    switch (status) {
        case AVAuthorizationStatusNotDetermined:{
            [AVCaptureDevice requestAccessForMediaType:AVMediaTypeVideo completionHandler:^(BOOL granted) {
                if (granted) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [_self.session setRunning:YES];
                    });
                }
            }];
            break;
        }
        case AVAuthorizationStatusAuthorized:
            [_self.session setRunning:YES];
            break;
            case AVAuthorizationStatusDenied:
            case AVAuthorizationStatusRestricted:
            break;
        default:
            break;
    }
}

#pragma mark -- LFStreamingSessionDelegate
/** live status changed will callback */
- (void)liveSession:(nullable LFLiveSession *)session liveStateDidChange:(LFLiveState)state {
    NSLog(@"liveStateDidChange: %ld", state);
    switch (state) {
        case LFLiveReady:
            _stateLabel.text = @"未连接";
            break;
        case LFLivePending:
            _stateLabel.text = @"连接中";
            break;
        case LFLiveStart:
            _stateLabel.text = @"已连接";
            break;
        case LFLiveError:
            _stateLabel.text = @"连接错误";
            break;
        case LFLiveStop:
            _stateLabel.text = @"未连接";
            break;
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
