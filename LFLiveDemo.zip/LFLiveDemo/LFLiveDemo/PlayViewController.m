//
//  PlayViewController.m
//  LFLiveDemo
//
//  Created by Apple on 16/9/1.
//  Copyright © 2016年 JunLiu. All rights reserved.
//

#import "PlayViewController.h"
#import <IJKMediaFramework/IJKMediaFramework.h>
@interface PlayViewController ()
@property(nonatomic,strong)NSURL *url;
@property(nonatomic)id <IJKMediaPlayback>player;
@property(nonatomic,strong)UIView *showView;
@end

@implementation PlayViewController

-(void)viewWillAppear:(BOOL)animated{
    if (![self.player isPlaying]) {
        [self.player prepareToPlay];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self playing];
}

-(void)playing{
    _url = [NSURL URLWithString:@"rtmp://live.hkstv.hk.lxdns.com:1935/live/stream152"];
    _player = [[IJKFFMoviePlayerController alloc]initWithContentURL:self.url withOptions:nil];
    UIView *playerView = [self.player view];
    UIView *displayView = [[UIView alloc]initWithFrame:self.view.bounds];
    self.showView = displayView;
    [self.view addSubview:_showView];
    playerView.frame = self.showView.bounds;
    playerView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [self.showView insertSubview:playerView atIndex:1];
    [_player setScalingMode:IJKMPMovieScalingModeAspectFill];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
